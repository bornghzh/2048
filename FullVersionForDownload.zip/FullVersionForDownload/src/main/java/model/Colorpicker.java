package model;

import javafx.scene.paint.Color;

public final class Colorpicker {

    static final String[] color = {

    };

    static final Color[] colors = {
       Color.BLUE, Color.RED, Color.VIOLET, Color.AQUAMARINE, Color.ANTIQUEWHITE, Color.DARKGREEN, Color.BISQUE,
            Color.YELLOW, Color.YELLOWGREEN, Color.GREY, Color.BROWN
    } ;

}